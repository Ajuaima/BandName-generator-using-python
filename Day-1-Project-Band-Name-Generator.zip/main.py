print("Welcome to the band generator!!")
city = (input("What city did you grow up in?\n"))
pet = (input("What is the name of your pet?\n"))
print("The name of your band should be" + " " + city + " " + pet)
